package com.example.kursova1;

///Підʼєднання модулів
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import java.io.IOException;
import java.io.*;

///Головний клас
public class HelloController {
    ///Змінна для передачі загальної вартості в чек
    Integer CheckPrice = 0;
    ///Змінні для зберігання інформації про роботу
    String CarNumber = "";
    String MarkaAuto = "";
    String PIPofMaister = "";
    String KlientContacts = "";
    String Date = "";
    ///Змінні для цін на послуги
    ///Значення будуть братись з "Ціни/Price.txt"
    Integer PriceOfDiagDvig = 0;
    Integer PriceOfDiagElek = 0;
    Integer PriceOfDiagHod = 0;
    Integer PriceOfDiagKomp = 0;
    Integer PriceOfDiagKuz = 0;
    Integer PriceOfDiagOhol = 0;
    Integer PriceOfHodoPidsh = 0;
    Integer PriceOfHodoPiln = 0;
    Integer PriceOfHodoRich = 0;
    Integer PriceOfHodoSail = 0;
    Integer PriceOfHodoStoi = 0;
    Integer PriceOfHodoTorm = 0;
    Integer PriceOfKuzPidg = 0;
    Integer PriceOfKuzPol = 0;
    Integer PriceOfKuzPom = 0;
    Integer PriceOfKuzPova = 0;
    Integer PriceOfKuzVmy = 0;
    Integer PriceOfKuzZaz = 0;
    Integer PriceOfMotorBlok = 0;
    Integer PriceOfMotorHolova = 0;
    Integer PriceOfMotorPromivka = 0;
    Integer PriceOfMotorRosh = 0;
    Integer PriceOfMotorSumish = 0;
    Integer PriceOfMotorZapalenna = 0;
    Integer PriceOfElektrikFara = 0;
    Integer PriceOfElektrikKabel = 0;
    Integer PriceOfElektrikMagnitola = 0;
    Integer PriceOfElektrikPerepayka = 0;
    Integer PriceOfElektrikPidsvitka = 0;
    Integer PriceOfOtherChip = 0;
    Integer PriceOfOtherOmivach = 0;
    Integer PriceOfOtherPichka = 0;
    Integer PriceOfOtherTisk = 0;
    Integer PriceOfOtherTonirovka = 0;

    ///Код Scene Builder (початок)
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Label HelloLabel;

    @FXML
    private CheckBox OkDiagDvig;

    @FXML
    private CheckBox OkDiagElek;

    @FXML
    private CheckBox OkDiagHod;

    @FXML
    private CheckBox OkDiagKomp;

    @FXML
    private CheckBox OkDiagKuz;

    @FXML
    private CheckBox OkDiagOhol;

    @FXML
    private CheckBox OkElektrikFara;

    @FXML
    private CheckBox OkElektrikKabel;

    @FXML
    private CheckBox OkElektrikMagnitola;

    @FXML
    private CheckBox OkElektrikPerepayka;

    @FXML
    private CheckBox OkElektrikPidsvitka;

    @FXML
    private CheckBox OkHodoPidsh;

    @FXML
    private CheckBox OkHodoPiln;

    @FXML
    private CheckBox OkHodoRich;

    @FXML
    private CheckBox OkHodoSail;

    @FXML
    private CheckBox OkHodoStoi;

    @FXML
    private CheckBox OkHodoTorm;

    @FXML
    private CheckBox OkKuzPidg;

    @FXML
    private CheckBox OkKuzPol;

    @FXML
    private CheckBox OkKuzPom;

    @FXML
    private CheckBox OkKuzPova;

    @FXML
    private CheckBox OkKuzVmy;

    @FXML
    private CheckBox OkKuzZaz;

    @FXML
    private CheckBox OkMotorBlok;

    @FXML
    private CheckBox OkMotorHolova;

    @FXML
    private CheckBox OkMotorPromivka;

    @FXML
    private CheckBox OkMotorRosh;

    @FXML
    private CheckBox OkMotorSumish;

    @FXML
    private CheckBox OkMotorZapalenna;

    @FXML
    private CheckBox OkOtherChip;

    @FXML
    private CheckBox OkOtherOmivach;

    @FXML
    private CheckBox OkOtherPichka;

    @FXML
    private CheckBox OkOtherTisk;

    @FXML
    private CheckBox OkOtherTonirovka;

    @FXML
    private Button checkBtn;

    @FXML
    private Label datalabel;

    @FXML
    private Button diagnostikaBtn;

    @FXML
    private Button elektrikBtn;

    @FXML
    private Button exitBtn;

    @FXML
    private TextField field10changeprZamSai;

    @FXML
    private TextField field11changeprZamRic;

    @FXML
    private TextField field12changeprZamPil;

    @FXML
    private TextField field13changeprPovarka;

    @FXML
    private TextField field15changeprZazoriv;

    @FXML
    private TextField field16changeprPidgotov;

    @FXML
    private TextField field17changeprPoliruv;

    @FXML
    private TextField field18changeprRoshid;

    @FXML
    private TextField field19changeprRemHol;

    @FXML
    private TextField field1chageprDiaHod;

    @FXML
    private TextField field20changeprRemBlok;

    @FXML
    private TextField field21changeprNalZapal;

    @FXML
    private TextField field22changeprNalSumish;

    @FXML
    private TextField field23changeprPromivka;

    @FXML
    private TextField field24changeprPerepayka;

    @FXML
    private TextField field25changepriceRemFar;

    @FXML
    private TextField field26changeprMagnitola;

    @FXML
    private TextField field27changprPidsvitka;

    @FXML
    private TextField field28changeprKabelMen;

    @FXML
    private TextField field29changprTisk;

    @FXML
    private TextField field2changeprDiaKuz;

    @FXML
    private TextField field30changprTonyvanna;

    @FXML
    private TextField field31changeprPichka;

    @FXML
    private TextField field32changprOmivach;

    @FXML
    private TextField field33changprChipTyn;

    @FXML
    private TextField field34changeprPomal;

    @FXML
    private TextField field3changeprDiaDvi;

    @FXML
    private TextField field4changeprDiaEle;

    @FXML
    private TextField field5changeprDiaOho;

    @FXML
    private TextField field6changeprKomDia;

    @FXML
    private TextField field7changeprZamTor;

    @FXML
    private TextField field8changeprZamSto;

    @FXML
    private TextField field9changeprZamPid;

    @FXML
    private TextField fieldHellloDate;

    @FXML
    private TextField fieldHellloKlientNuber;

    @FXML
    private TextField fieldHellloPipMaister;

    @FXML
    private TextField fieldHelloMarkaAuto;

    @FXML
    private TextField fieldHelloNumber;

    @FXML
    private TextField fieldOfKtKlapaniv;

    @FXML
    private TextField fieldOfKtPorshniv;

    @FXML
    private TextField fieldOfPid;

    @FXML
    private TextField fieldOfPidsh;

    @FXML
    private TextField fieldOfPiln;

    @FXML
    private TextField fieldOfPol;

    @FXML
    private TextField fieldOfPom;

    @FXML
    private TextField fieldOfPov;

    @FXML
    private TextField fieldOfRich;

    @FXML
    private TextField fieldOfSail;

    @FXML
    private TextField fieldOfStoi;

    @FXML
    private TextField fieldOfTorm;

    @FXML
    private TextField fieldOfVmy;

    @FXML
    private TextField fieldOfZaz;

    @FXML
    private TextField filed14changeprVmyatin;

    @FXML
    private Button helloOkBtn;

    @FXML
    private Button hodovaBtn;

    @FXML
    private Label klientnumber;

    @FXML
    private Label ktKlapaniv;

    @FXML
    private Label ktPorshniv;

    @FXML
    private Button kuzovBtn;

    @FXML
    private Label markaauto;

    @FXML
    private Button motorBtn;

    @FXML
    private Label nfslogo;

    @FXML
    private Label nfslogo3;

    @FXML
    private Label nomerxnak;

    @FXML
    private Button otherBtn;

    @FXML
    private AnchorPane paneHomePage;

    @FXML
    private AnchorPane paneOfDiagnostik;

    @FXML
    private AnchorPane paneOfElektrik;

    @FXML
    private AnchorPane paneOfHello;

    @FXML
    private AnchorPane paneOfHodova;

    @FXML
    private AnchorPane paneOfKuzov;

    @FXML
    private AnchorPane paneOfMotor;

    @FXML
    private AnchorPane paneOfOther;

    @FXML
    private AnchorPane paneOfSettingLabels;

    @FXML
    private Label pipmaister;

    @FXML
    private Label poslugu;

    @FXML
    private Button settingOkBtn;

    @FXML
    private Button settingsBtn;

    @FXML
    private Label totalprice;

    @FXML
    private Label zagalnavartist;

    @FXML
    void initialize() {
        assert HelloLabel != null : "fx:id=\"HelloLabel\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkDiagDvig != null : "fx:id=\"OkDiagDvig\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkDiagElek != null : "fx:id=\"OkDiagElek\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkDiagHod != null : "fx:id=\"OkDiagHod\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkDiagKomp != null : "fx:id=\"OkDiagKomp\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkDiagKuz != null : "fx:id=\"OkDiagKuz\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkDiagOhol != null : "fx:id=\"OkDiagOhol\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkElektrikFara != null : "fx:id=\"OkElektrikFara\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkElektrikKabel != null : "fx:id=\"OkElektrikKabel\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkElektrikMagnitola != null : "fx:id=\"OkElektrikMagnitola\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkElektrikPerepayka != null : "fx:id=\"OkElektrikPerepayka\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkElektrikPidsvitka != null : "fx:id=\"OkElektrikPidsvitka\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkHodoPidsh != null : "fx:id=\"OkHodoPidsh\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkHodoPiln != null : "fx:id=\"OkHodoPiln\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkHodoRich != null : "fx:id=\"OkHodoRich\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkHodoSail != null : "fx:id=\"OkHodoSail\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkHodoStoi != null : "fx:id=\"OkHodoStoi\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkHodoTorm != null : "fx:id=\"OkHodoTorm\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkKuzPidg != null : "fx:id=\"OkKuzPidg\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkKuzPol != null : "fx:id=\"OkKuzPol\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkKuzPom != null : "fx:id=\"OkKuzPom\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkKuzPova != null : "fx:id=\"OkKuzPova\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkKuzVmy != null : "fx:id=\"OkKuzVmy\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkKuzZaz != null : "fx:id=\"OkKuzZaz\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkMotorBlok != null : "fx:id=\"OkMotorBlok\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkMotorHolova != null : "fx:id=\"OkMotorHolova\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkMotorPromivka != null : "fx:id=\"OkMotorPromivka\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkMotorRosh != null : "fx:id=\"OkMotorRosh\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkMotorSumish != null : "fx:id=\"OkMotorSumish\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkMotorZapalenna != null : "fx:id=\"OkMotorZapalenna\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkOtherChip != null : "fx:id=\"OkOtherChip\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkOtherOmivach != null : "fx:id=\"OkOtherOmivach\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkOtherPichka != null : "fx:id=\"OkOtherPichka\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkOtherTisk != null : "fx:id=\"OkOtherTisk\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert OkOtherTonirovka != null : "fx:id=\"OkOtherTonirovka\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert checkBtn != null : "fx:id=\"checkBtn\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert datalabel != null : "fx:id=\"datalabel\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert diagnostikaBtn != null : "fx:id=\"diagnostikaBtn\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert elektrikBtn != null : "fx:id=\"elektrikBtn\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert exitBtn != null : "fx:id=\"exitBtn\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field10changeprZamSai != null : "fx:id=\"field10changeprZamSai\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field11changeprZamRic != null : "fx:id=\"field11changeprZamRic\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field12changeprZamPil != null : "fx:id=\"field12changeprZamPil\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field13changeprPovarka != null : "fx:id=\"field13changeprPovarka\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field15changeprZazoriv != null : "fx:id=\"field15changeprZazoriv\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field16changeprPidgotov != null : "fx:id=\"field16changeprPidgotov\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field17changeprPoliruv != null : "fx:id=\"field17changeprPoliruv\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field18changeprRoshid != null : "fx:id=\"field18changeprRoshid\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field19changeprRemHol != null : "fx:id=\"field19changeprRemHol\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field1chageprDiaHod != null : "fx:id=\"field1chageprDiaHod\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field20changeprRemBlok != null : "fx:id=\"field20changeprRemBlok\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field21changeprNalZapal != null : "fx:id=\"field21changeprNalZapal\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field22changeprNalSumish != null : "fx:id=\"field22changeprNalSumish\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field23changeprPromivka != null : "fx:id=\"field23changeprPromivka\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field24changeprPerepayka != null : "fx:id=\"field24changeprPerepayka\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field25changepriceRemFar != null : "fx:id=\"field25changepriceRemFar\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field26changeprMagnitola != null : "fx:id=\"field26changeprMagnitola\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field27changprPidsvitka != null : "fx:id=\"field27changprPidsvitka\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field28changeprKabelMen != null : "fx:id=\"field28changeprKabelMen\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field29changprTisk != null : "fx:id=\"field29changprTisk\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field2changeprDiaKuz != null : "fx:id=\"field2changeprDiaKuz\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field30changprTonyvanna != null : "fx:id=\"field30changprTonyvanna\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field31changeprPichka != null : "fx:id=\"field31changeprPichka\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field32changprOmivach != null : "fx:id=\"field32changprOmivach\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field33changprChipTyn != null : "fx:id=\"field33changprChipTyn\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field34changeprPomal != null : "fx:id=\"field34changeprPomal\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field3changeprDiaDvi != null : "fx:id=\"field3changeprDiaDvi\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field4changeprDiaEle != null : "fx:id=\"field4changeprDiaEle\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field5changeprDiaOho != null : "fx:id=\"field5changeprDiaOho\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field6changeprKomDia != null : "fx:id=\"field6changeprKomDia\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field7changeprZamTor != null : "fx:id=\"field7changeprZamTor\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field8changeprZamSto != null : "fx:id=\"field8changeprZamSto\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert field9changeprZamPid != null : "fx:id=\"field9changeprZamPid\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert fieldHellloDate != null : "fx:id=\"fieldHellloDate\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert fieldHellloKlientNuber != null : "fx:id=\"fieldHellloKlientNuber\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert fieldHellloPipMaister != null : "fx:id=\"fieldHellloPipMaister\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert fieldHelloMarkaAuto != null : "fx:id=\"fieldHelloMarkaAuto\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert fieldHelloNumber != null : "fx:id=\"fieldHelloNumber\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert fieldOfKtKlapaniv != null : "fx:id=\"fieldOfKtKlapaniv\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert fieldOfKtPorshniv != null : "fx:id=\"fieldOfKtPorshniv\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert fieldOfPid != null : "fx:id=\"fieldOfPid\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert fieldOfPidsh != null : "fx:id=\"fieldOfPidsh\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert fieldOfPiln != null : "fx:id=\"fieldOfPiln\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert fieldOfPol != null : "fx:id=\"fieldOfPol\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert fieldOfPom != null : "fx:id=\"fieldOfPom\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert fieldOfPov != null : "fx:id=\"fieldOfPov\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert fieldOfRich != null : "fx:id=\"fieldOfRich\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert fieldOfSail != null : "fx:id=\"fieldOfSail\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert fieldOfStoi != null : "fx:id=\"fieldOfStoi\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert fieldOfTorm != null : "fx:id=\"fieldOfTorm\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert fieldOfVmy != null : "fx:id=\"fieldOfVmy\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert fieldOfZaz != null : "fx:id=\"fieldOfZaz\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert filed14changeprVmyatin != null : "fx:id=\"filed14changeprVmyatin\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert helloOkBtn != null : "fx:id=\"helloOkBtn\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert hodovaBtn != null : "fx:id=\"hodovaBtn\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert klientnumber != null : "fx:id=\"klientnumber\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert ktKlapaniv != null : "fx:id=\"ktKlapaniv\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert ktPorshniv != null : "fx:id=\"ktPorshniv\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert kuzovBtn != null : "fx:id=\"kuzovBtn\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert markaauto != null : "fx:id=\"markaauto\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert motorBtn != null : "fx:id=\"motorBtn\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert nfslogo != null : "fx:id=\"nfslogo\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert nfslogo3 != null : "fx:id=\"nfslogo3\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert nomerxnak != null : "fx:id=\"nomerxnak\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert otherBtn != null : "fx:id=\"otherBtn\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert paneHomePage != null : "fx:id=\"paneHomePage\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert paneOfDiagnostik != null : "fx:id=\"paneOfDiagnostik\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert paneOfElektrik != null : "fx:id=\"paneOfElektrik\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert paneOfHello != null : "fx:id=\"paneOfHello\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert paneOfHodova != null : "fx:id=\"paneOfHodova\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert paneOfKuzov != null : "fx:id=\"paneOfKuzov\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert paneOfMotor != null : "fx:id=\"paneOfMotor\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert paneOfOther != null : "fx:id=\"paneOfOther\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert paneOfSettingLabels != null : "fx:id=\"paneOfSettingLabels\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert pipmaister != null : "fx:id=\"pipmaister\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert poslugu != null : "fx:id=\"poslugu\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert settingOkBtn != null : "fx:id=\"settingOkBtn\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert settingsBtn != null : "fx:id=\"settingsBtn\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert totalprice != null : "fx:id=\"totalprice\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert zagalnavartist != null : "fx:id=\"zagalnavartist\" was not injected: check your FXML file 'hello-view.fxml'.";
        ///Код Scene Builder (кінець)

        ///Кнопка "Далі" з привітального до основного вікна
        helloOkBtn.setOnAction(event -> goToHomePageFromHelloPage());

        ///Кнопки для переключення категорій послуг
        diagnostikaBtn.setOnAction(event -> showDiagnostikaBoxes());
        hodovaBtn.setOnAction(event -> showHodovaBoxes());
        kuzovBtn.setOnAction(event -> showKuzovBoxes());
        motorBtn.setOnAction(event -> showMotorBoxes());
        elektrikBtn.setOnAction(event -> showElektrikBoxes());
        otherBtn.setOnAction(event -> showOtherBoxes());

        ///Кнопка "Вийти"
        exitBtn.setOnAction(event -> exit());

        ///Кнопка для переходу у панель налаштування цін
        settingsBtn.setOnAction(event -> goToSettings());

        ///Кнопка "Готово" до говної панелі від панелі налаштувань
        settingOkBtn.setOnAction(event -> goToHomePage());

        ///Перемикачі для вибору послуг
        OkDiagDvig.setOnAction(event -> showPrice());
        OkDiagElek.setOnAction(event -> showPrice());
        OkDiagHod.setOnAction(event -> showPrice());
        OkDiagKomp.setOnAction(event -> showPrice());
        OkDiagKuz.setOnAction(event -> showPrice());
        OkDiagOhol.setOnAction(event -> showPrice());
        OkHodoPidsh.setOnAction(event -> showPrice());
        OkHodoPiln.setOnAction(event -> showPrice());
        OkHodoRich.setOnAction(event -> showPrice());
        OkHodoSail.setOnAction(event -> showPrice());
        OkHodoStoi.setOnAction(event -> showPrice());
        OkHodoTorm.setOnAction(event -> showPrice());
        OkKuzPidg.setOnAction(event -> showPrice());
        OkKuzPol.setOnAction(event -> showPrice());
        OkKuzPom.setOnAction(event -> showPrice());
        OkKuzPova.setOnAction(event -> showPrice());
        OkKuzVmy.setOnAction(event -> showPrice());
        OkKuzZaz.setOnAction(event -> showPrice());
        OkMotorBlok.setOnAction(event -> showPrice());
        OkMotorHolova.setOnAction(event -> showPrice());
        OkMotorPromivka.setOnAction(event -> showPrice());
        OkMotorRosh.setOnAction(event -> showPrice());
        OkMotorSumish.setOnAction(event -> showPrice());
        OkMotorZapalenna.setOnAction(event -> showPrice());
        OkElektrikFara.setOnAction(event -> showPrice());
        OkElektrikKabel.setOnAction(event -> showPrice());
        OkElektrikMagnitola.setOnAction(event -> showPrice());
        OkElektrikPerepayka.setOnAction(event -> showPrice());
        OkElektrikPidsvitka.setOnAction(event -> showPrice());
        OkOtherChip.setOnAction(event -> showPrice());
        OkOtherOmivach.setOnAction(event -> showPrice());
        OkOtherPichka.setOnAction(event -> showPrice());
        OkOtherTisk.setOnAction(event -> showPrice());
        OkOtherTonirovka.setOnAction(event -> showPrice());

        ///Кнопка для створення фіскального чеку
        checkBtn.setOnAction(event -> check());

        ///Функція для приховання всіх панелів вибору послуг (AnchorPane-нів)
        BoxesVisibleOff();

        ///Функція для обробки та показу загальної вартості
        showPrice();
    }

    ///Перехід з інформаційної до головної панелі
    ///Та запамʼятовування введеної інформації у змінні
    public void goToHomePageFromHelloPage() {
        MarkaAuto = (fieldHelloMarkaAuto.getText());
        CarNumber = (fieldHelloNumber.getText());
        PIPofMaister = (fieldHellloPipMaister.getText());
        KlientContacts = (fieldHellloKlientNuber.getText());
        Date = (fieldHellloDate.getText());
        paneOfHello.setVisible(false);

        ///Встановлення актуальних цін на основі документа.
        setPrices();
    }

    ///Функція для встановлення цін згідно документу "Ціни/Price.txt"
    public void setPrices(){
        ///Лічильний круга циклу для визначення номеру рядка документу
        Integer LineOfPriceTxt = 1;

        try(BufferedReader br = new BufferedReader(new FileReader("Ціни/Price.txt")))
        {
            ///Змінна s - це буде значення рядка
            String s;

            while((s=br.readLine())!=null) {
                ///Перевірки номерів рядка та встановлення цін
                if (LineOfPriceTxt==2) PriceOfDiagDvig = Integer.valueOf(s);
                if (LineOfPriceTxt==4) PriceOfDiagElek = Integer.valueOf(s);
                if (LineOfPriceTxt==6) PriceOfDiagHod = Integer.valueOf(s);
                if (LineOfPriceTxt==8) PriceOfDiagKomp = Integer.valueOf(s);
                if (LineOfPriceTxt==10) PriceOfDiagKuz = Integer.valueOf(s);
                if (LineOfPriceTxt==12) PriceOfDiagOhol = Integer.valueOf(s);
                if (LineOfPriceTxt==14) PriceOfHodoPidsh = Integer.valueOf(s);
                if (LineOfPriceTxt==16) PriceOfHodoPiln = Integer.valueOf(s);
                if (LineOfPriceTxt==18) PriceOfHodoRich = Integer.valueOf(s);
                if (LineOfPriceTxt==20) PriceOfHodoSail = Integer.valueOf(s);
                if (LineOfPriceTxt==22) PriceOfHodoStoi = Integer.valueOf(s);
                if (LineOfPriceTxt==24) PriceOfHodoTorm = Integer.valueOf(s);
                if (LineOfPriceTxt==26) PriceOfKuzPidg = Integer.valueOf(s);
                if (LineOfPriceTxt==28) PriceOfKuzPol = Integer.valueOf(s);
                if (LineOfPriceTxt==30) PriceOfKuzPom = Integer.valueOf(s);
                if (LineOfPriceTxt==32) PriceOfKuzPova = Integer.valueOf(s);
                if (LineOfPriceTxt==34) PriceOfKuzVmy = Integer.valueOf(s);
                if (LineOfPriceTxt==36) PriceOfKuzZaz = Integer.valueOf(s);
                if (LineOfPriceTxt==38) PriceOfMotorBlok = Integer.valueOf(s);
                if (LineOfPriceTxt==40) PriceOfMotorHolova = Integer.valueOf(s);
                if (LineOfPriceTxt==42) PriceOfMotorPromivka = Integer.valueOf(s);
                if (LineOfPriceTxt==44) PriceOfMotorRosh = Integer.valueOf(s);
                if (LineOfPriceTxt==46) PriceOfMotorSumish = Integer.valueOf(s);
                if (LineOfPriceTxt==48) PriceOfMotorZapalenna = Integer.valueOf(s);
                if (LineOfPriceTxt==50) PriceOfElektrikFara = Integer.valueOf(s);
                if (LineOfPriceTxt==52) PriceOfElektrikKabel = Integer.valueOf(s);
                if (LineOfPriceTxt==54) PriceOfElektrikMagnitola = Integer.valueOf(s);
                if (LineOfPriceTxt==56) PriceOfElektrikPerepayka = Integer.valueOf(s);
                if (LineOfPriceTxt==58) PriceOfElektrikPidsvitka = Integer.valueOf(s);
                if (LineOfPriceTxt==60) PriceOfOtherChip = Integer.valueOf(s);
                if (LineOfPriceTxt==62) PriceOfOtherOmivach = Integer.valueOf(s);
                if (LineOfPriceTxt==64) PriceOfOtherPichka = Integer.valueOf(s);
                if (LineOfPriceTxt==66) PriceOfOtherTisk = Integer.valueOf(s);
                if (LineOfPriceTxt==68) PriceOfOtherTonirovka = Integer.valueOf(s);

                ///Збільшення змінної-лічильника циклу
                LineOfPriceTxt += 1;
            }
        }
        catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }

    ///Функція для приховання всіх панелів вибору послуг (AnchorPane-нів)
    private void BoxesVisibleOff() {
        paneOfDiagnostik.setVisible(false);
        paneOfHodova.setVisible(false);
        paneOfKuzov.setVisible(false);
        paneOfMotor.setVisible(false);
        paneOfElektrik.setVisible(false);
        paneOfOther.setVisible(false);
        paneOfSettingLabels.setVisible(false);
    }

    ///Функція для показу елементів панелі "Діагностика"
    private void showDiagnostikaBoxes() {
        BoxesVisibleOff();
        paneOfDiagnostik.setVisible(true);
    }

    ///Функція для показу елементів панелі "Ремонт ходової"
    private void showHodovaBoxes() {
        BoxesVisibleOff();
        paneOfHodova.setVisible(true);
    }

    ///Функція для показу елементів панелі "Кузовний ремонт"
    private void showKuzovBoxes() {
        BoxesVisibleOff();
        paneOfKuzov.setVisible(true);
    }

    ///Функція для показу елементів панелі "Постуги моториста"
    private void showMotorBoxes() {
        BoxesVisibleOff();
        paneOfMotor.setVisible(true);
    }

    ///Функція для показу елементів панелі "Послуги електрика"
    private void showElektrikBoxes() {
        BoxesVisibleOff();
        paneOfElektrik.setVisible(true);
    }

    ///Функція для показу елементів панелі "Інше"
    private void showOtherBoxes() {
        BoxesVisibleOff();
        paneOfOther.setVisible(true);
    }

    ///Функція для кнопки "Вихід" для виходу з програми
    private void exit() {
        System.exit(0);
    }

    ///Функція для обробки та показу загальної вартості
    ///Вона буде викликатись при кожній дії на CheckBox-и послуг
    private void showPrice() {
        ///Змінна загальної вартості
        Integer TOTAL_Price = 0;

        ///Перевірка на дію та зміна загальної вартості
        if (OkDiagDvig.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfDiagDvig;
        if (OkDiagElek.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfDiagElek;
        if (OkDiagHod.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfDiagHod;
        if (OkDiagKomp.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfDiagKomp;
        if (OkDiagKuz.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfDiagKuz;
        if (OkDiagOhol.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfDiagOhol;
        if (OkHodoPidsh.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfHodoPidsh * Integer.valueOf(fieldOfPidsh.getText());
        if (OkHodoPiln.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfHodoPiln * Integer.valueOf(fieldOfPiln.getText());
        if (OkHodoRich.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfHodoRich * Integer.valueOf(fieldOfRich.getText());
        if (OkHodoSail.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfHodoSail * Integer.valueOf(fieldOfSail.getText());
        if (OkHodoStoi.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfHodoStoi * Integer.valueOf(fieldOfStoi.getText());
        if (OkHodoTorm.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfHodoTorm * Integer.valueOf(fieldOfTorm.getText());
        if (OkKuzZaz.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfKuzZaz * Integer.valueOf(fieldOfZaz.getText());
        if (OkKuzVmy.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfKuzVmy * Integer.valueOf(fieldOfVmy.getText());
        if (OkKuzPova.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfKuzPova * Integer.valueOf(fieldOfPov.getText());
        if (OkKuzPom.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfKuzPom * Integer.valueOf(fieldOfPom.getText());
        if (OkKuzPol.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfKuzPol * Integer.valueOf(fieldOfPol.getText());
        if (OkKuzPidg.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfKuzPidg * Integer.valueOf(fieldOfPid.getText());
        if (OkMotorBlok.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfMotorBlok * Integer.valueOf(fieldOfKtPorshniv.getText());
        if (OkMotorHolova.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfMotorHolova * Integer.valueOf(fieldOfKtKlapaniv.getText());
        if (OkMotorPromivka.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfMotorPromivka;
        if (OkMotorRosh.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfMotorRosh;
        if (OkMotorSumish.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfMotorSumish;
        if (OkMotorZapalenna.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfMotorZapalenna;
        if (OkElektrikFara.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfElektrikFara;
        if (OkElektrikKabel.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfElektrikKabel;
        if (OkElektrikMagnitola.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfElektrikMagnitola;
        if (OkElektrikPerepayka.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfElektrikPerepayka;
        if (OkElektrikPidsvitka.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfElektrikPidsvitka;
        if (OkOtherChip.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfOtherChip;
        if (OkOtherOmivach.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfOtherOmivach;
        if (OkOtherPichka.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfOtherPichka;
        if (OkOtherTisk.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfOtherTisk;
        if (OkOtherTonirovka.isSelected()) TOTAL_Price = TOTAL_Price + PriceOfOtherTonirovka;

        ///Зміна загальної вартості у Label-і totalprice
        totalprice.setText(String.valueOf(TOTAL_Price));

        ///Передача значення загальної вартості з програми у загальну вартість в чеку
        CheckPrice = TOTAL_Price;
    }

    ///Функція для створення фіскального чеку
    private void check() {
        ///Створення файлу з вказанням номера авто у назві
        try(FileWriter writer = new FileWriter("Чеки/Чек_"+CarNumber+".txt", false))
        {
            ///Заповнення інформацією
            String text = "\t\t\t\tФіскальний чек";
            writer.write(text);
            writer.append('\n' + "\t\t\t\t NFS-Сервіс");
            writer.append('\n');
            writer.append('\n');
            writer.append('\n' + "\t\tКлієнт: " + KlientContacts);
            writer.append('\n' + "\t\tМарка авто: " + MarkaAuto + " | " + CarNumber);
            writer.append('\n' + "\t\tМайтер: " + PIPofMaister);
            writer.append('\n');
            writer.append('\n');
            writer.append('\n' + "\t\t\t\tНадані послуги:");
            if (OkDiagDvig.isSelected()) writer.append('\n' + "\t\tДіагностика двигуна: " + String.valueOf(PriceOfDiagDvig));
            if (OkDiagElek.isSelected()) writer.append('\n' + "\t\tДіагностика електрики: " + String.valueOf(PriceOfDiagElek));
            if (OkDiagHod.isSelected()) writer.append('\n' + "\t\tДіагностика ходової: " + String.valueOf(PriceOfDiagHod));
            if (OkDiagKomp.isSelected()) writer.append('\n' + "\t\tДіагностика компʼютера: " + String.valueOf(PriceOfDiagKomp));
            if (OkDiagKuz.isSelected()) writer.append('\n' + "\t\tДіагностика кузова: " + String.valueOf(PriceOfDiagKuz));
            if (OkDiagOhol.isSelected()) writer.append('\n' + "\t\tДіагностика системи охолодження: " + String.valueOf(PriceOfDiagOhol));
            if (OkHodoPidsh.isSelected()) writer.append('\n' + "\t\tЗаміна підшипників: " + String.valueOf(PriceOfHodoPidsh * Integer.valueOf(fieldOfPidsh.getText())));
            if (OkHodoRich.isSelected()) writer.append('\n' + "\t\tЗаміна ричагів: " + String.valueOf(PriceOfHodoRich * Integer.valueOf(fieldOfRich.getText())));
            if (OkHodoSail.isSelected()) writer.append('\n' + "\t\tЗаміна сайлентблоків: " + String.valueOf(PriceOfHodoSail * Integer.valueOf(fieldOfSail.getText())));
            if (OkHodoStoi.isSelected()) writer.append('\n' + "\t\tЗаміна стойок: " + String.valueOf(PriceOfHodoStoi * Integer.valueOf(fieldOfStoi.getText())));
            if (OkHodoTorm.isSelected()) writer.append('\n' + "\t\tЗаміна тормозів: " + String.valueOf(PriceOfHodoTorm * Integer.valueOf(fieldOfTorm.getText())));
            if (OkKuzZaz.isSelected()) writer.append('\n' + "\t\tВиставлення зазорів: " + String.valueOf(PriceOfKuzZaz * Integer.valueOf(fieldOfZaz.getText())));
            if (OkKuzVmy.isSelected()) writer.append('\n' + "\t\tВитягнення вмʼятин: " + String.valueOf(PriceOfKuzVmy * Integer.valueOf(fieldOfVmy.getText())));
            if (OkKuzPova.isSelected()) writer.append('\n' + "\t\tЗварювальні роботи: " + String.valueOf(PriceOfKuzPova * Integer.valueOf(fieldOfPov.getText())));
            if (OkKuzPom.isSelected()) writer.append('\n' + "\t\tМалярні роботи: " + String.valueOf(PriceOfKuzPom * Integer.valueOf(fieldOfPom.getText())));
            if (OkKuzPol.isSelected()) writer.append('\n' + "\t\tПолірування: " + String.valueOf(PriceOfKuzPol * Integer.valueOf(fieldOfPol.getText())));
            if (OkKuzPidg.isSelected()) writer.append('\n' + "\t\tПідготовка деталей: " + String.valueOf(PriceOfKuzPidg * Integer.valueOf(fieldOfPid.getText())));
            if (OkMotorBlok.isSelected()) writer.append('\n' + "\t\tРемонт блока двигуна: " + String.valueOf(PriceOfMotorBlok * Integer.valueOf(fieldOfKtPorshniv.getText())));
            if (OkMotorHolova.isSelected()) writer.append('\n' + "\t\tРемонт головки двигуна: " + String.valueOf(PriceOfMotorHolova * Integer.valueOf(fieldOfKtKlapaniv.getText())));
            if (OkMotorPromivka.isSelected()) writer.append('\n' + "\t\tПромивка двигуна: " + String.valueOf(PriceOfMotorPromivka));
            if (OkMotorRosh.isSelected()) writer.append('\n' + "\t\tЗаміна розхідників двигуна: " + String.valueOf(PriceOfMotorRosh));
            if (OkMotorSumish.isSelected()) writer.append('\n' + "\t\tНалаштування суміші: " + String.valueOf(PriceOfMotorSumish));
            if (OkMotorZapalenna.isSelected()) writer.append('\n' + "\t\tНалаштування запалення: " + String.valueOf(PriceOfMotorZapalenna));
            if (OkElektrikFara.isSelected()) writer.append('\n' + "\t\tРемонт світла фар: " + String.valueOf(PriceOfElektrikFara));
            if (OkElektrikKabel.isSelected()) writer.append('\n' + "\t\tКабель менеджмент: " + String.valueOf(PriceOfElektrikKabel));
            if (OkElektrikMagnitola.isSelected()) writer.append('\n' + "\t\tЗаміна автомагнітоли: " + String.valueOf(PriceOfElektrikMagnitola));
            if (OkElektrikPerepayka.isSelected()) writer.append('\n' + "\t\tПерепацка проводів: " + String.valueOf(PriceOfElektrikPerepayka));
            if (OkElektrikPidsvitka.isSelected()) writer.append('\n' + "\t\tВстановлення підсвітки: " + String.valueOf(PriceOfElektrikPidsvitka));
            if (OkOtherChip.isSelected()) writer.append('\n' + "\t\tЧіп-тюнінг: " + String.valueOf(PriceOfOtherChip));
            if (OkOtherOmivach.isSelected()) writer.append('\n' + "\t\tЗаміна омивача: " + String.valueOf(PriceOfOtherOmivach));
            if (OkOtherPichka.isSelected()) writer.append('\n' + "\t\tПромивка радіатора пічки: " + String.valueOf(PriceOfOtherPichka));
            if (OkOtherTisk.isSelected()) writer.append('\n' + "\t\tЗрівнення тиску в шинах: " + String.valueOf(PriceOfOtherTisk));
            if (OkOtherTonirovka.isSelected()) writer.append('\n' + "\t\tТонування автомобіля: " + String.valueOf(PriceOfOtherTonirovka));
            writer.append('\n');
            writer.append('\n');
            writer.append('\n' + "\t\t\tЗагальна сума: " + String.valueOf(CheckPrice) + " гривень.");
            writer.append('\n');
            writer.append('\n');
            writer.append('\n' + "\t\t\t\t" + Date);
            ///Завершення запису
            writer.flush();
        }
        catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }

    ///Функція для переходу в панель налаштування цін
    public void goToSettings(){
        paneOfSettingLabels.setVisible(true);
        paneHomePage.setVisible(false);
    }

    ///Функція для переходу у головну панель
    ///Та оновлення цін
    public void goToHomePage(){
        ///Змінна для визначення кола цинклу
        Integer LineOfPriceTxt = 1;
        ///Берем допоміжний документ ("Ціни/Helper.txt"), з якого будемо залишати незмінену або текстову інформацію
        try(BufferedReader br = new BufferedReader(new FileReader("Ціни/Helper.txt")))
        {
            ///Берем документ цін ("Ціни/Price.txt"), в який будем записувати оновлену інформацію
            try(FileWriter writePrice = new FileWriter("Ціни/Price.txt", false))
            {
                ///Змінна для значення даного рядка
                String s;
                ///Цикл перебору рядків
                while((s=br.readLine())!=null) {
                    ///Перевірка на парні рядки (у них вказуються ціни на послуги)
                    if (LineOfPriceTxt%2==0) {
                        ///Перевірки номеру рядків
                            /*
                            За допомогою спроб try-catch перевіряємо чи в даному
                            TextField-і вказана нова ціна та ставимо її в новий
                            документ. У випадку, якщо наш TextField пустий тоді
                            ставимо у новий документ стару ціну, яку памʼятає
                            допоміжний документ.
                            */

                        if (LineOfPriceTxt==2) {
                            try {
                                writePrice.append(Integer.valueOf(field3changeprDiaDvi.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfDiagDvig + "\n");
                            }

                        }
                        if (LineOfPriceTxt==4) {
                            try {
                                writePrice.append(Integer.valueOf(field4changeprDiaEle.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfDiagElek + "\n");
                            }

                        }
                        if (LineOfPriceTxt==6) {
                            try {
                                writePrice.append(Integer.valueOf(field1chageprDiaHod.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfDiagHod + "\n");
                            }

                        }
                        if (LineOfPriceTxt==8) {
                            try {
                                writePrice.append(Integer.valueOf(field6changeprKomDia.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfDiagKomp + "\n");
                            }

                        }
                        if (LineOfPriceTxt==10) {
                            try {
                                writePrice.append(Integer.valueOf(field2changeprDiaKuz.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfDiagKuz + "\n");
                            }

                        }
                        if (LineOfPriceTxt==12) {
                            try {
                                writePrice.append(Integer.valueOf(field5changeprDiaOho.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfDiagOhol + "\n");
                            }

                        }
                        if (LineOfPriceTxt==14) {
                            try {
                                writePrice.append(Integer.valueOf(field9changeprZamPid.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfHodoPidsh + "\n");
                            }

                        }
                        if (LineOfPriceTxt==16) {
                            try {
                                writePrice.append(Integer.valueOf(field12changeprZamPil.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfHodoPiln + "\n");
                            }

                        }
                        if (LineOfPriceTxt==18) {
                            try {
                                writePrice.append(Integer.valueOf(field11changeprZamRic.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfHodoRich + "\n");
                            }

                        }
                        if (LineOfPriceTxt==20) {
                            try {
                                writePrice.append(Integer.valueOf(field10changeprZamSai.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfHodoSail + "\n");
                            }

                        }
                        if (LineOfPriceTxt==22) {
                            try {
                                writePrice.append(Integer.valueOf(field8changeprZamSto.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfHodoStoi + "\n");
                            }

                        }
                        if (LineOfPriceTxt==24) {
                            try {
                                writePrice.append(Integer.valueOf(field7changeprZamTor.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfHodoTorm + "\n");
                            }

                        }
                        if (LineOfPriceTxt==26) {
                            try {
                                writePrice.append(Integer.valueOf(field16changeprPidgotov.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfKuzPidg + "\n");
                            }

                        }
                        if (LineOfPriceTxt==28) {
                            try {
                                writePrice.append(Integer.valueOf(field17changeprPoliruv.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfKuzPol + "\n");
                            }

                        }
                        if (LineOfPriceTxt==30) {
                            try {
                                writePrice.append(Integer.valueOf(field34changeprPomal.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfKuzPom + "\n");
                            }

                        }
                        if (LineOfPriceTxt==32) {
                            try {
                                writePrice.append(Integer.valueOf(field13changeprPovarka.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfKuzPova + "\n");
                            }

                        }

                        if (LineOfPriceTxt==34) {
                            try {
                                writePrice.append(Integer.valueOf(filed14changeprVmyatin.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfKuzVmy + "\n");
                            }

                        }
                        if (LineOfPriceTxt==36) {
                            try {
                                writePrice.append(Integer.valueOf(field15changeprZazoriv.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfKuzZaz + "\n");
                            }

                        }
                        if (LineOfPriceTxt==38) {
                            try {
                                writePrice.append(Integer.valueOf(field20changeprRemBlok.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfMotorBlok + "\n");
                            }

                        }
                        if (LineOfPriceTxt==40) {
                            try {
                                writePrice.append(Integer.valueOf(field19changeprRemHol.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfMotorHolova + "\n");
                            }

                        }
                        if (LineOfPriceTxt==42) {
                            try {
                                writePrice.append(Integer.valueOf(field23changeprPromivka.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfMotorPromivka + "\n");
                            }

                        }
                        if (LineOfPriceTxt==44) {
                            try {
                                writePrice.append(Integer.valueOf(field18changeprRoshid.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfMotorRosh + "\n");
                            }

                        }
                        if (LineOfPriceTxt==46) {
                            try {
                                writePrice.append(Integer.valueOf(field22changeprNalSumish.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfMotorSumish + "\n");
                            }

                        }
                        if (LineOfPriceTxt==48) {
                            try {
                                writePrice.append(Integer.valueOf(field21changeprNalZapal.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfMotorZapalenna + "\n");
                            }

                        }
                        if (LineOfPriceTxt==50) {
                            try {
                                writePrice.append(Integer.valueOf(field25changepriceRemFar.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfElektrikFara + "\n");
                            }

                        }
                        if (LineOfPriceTxt==52) {
                            try {
                                writePrice.append(Integer.valueOf(field28changeprKabelMen.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfElektrikKabel + "\n");
                            }

                        }
                        if (LineOfPriceTxt==54) {
                            try {
                                writePrice.append(Integer.valueOf(field26changeprMagnitola.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfElektrikMagnitola + "\n");
                            }

                        }
                        if (LineOfPriceTxt==56) {
                            try {
                                writePrice.append(Integer.valueOf(field24changeprPerepayka.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfElektrikPerepayka + "\n");
                            }

                        }
                        if (LineOfPriceTxt==58) {
                            try {
                                writePrice.append(Integer.valueOf(field27changprPidsvitka.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfElektrikPidsvitka + "\n");
                            }

                        }
                        if (LineOfPriceTxt==60) {
                            try {
                                writePrice.append(Integer.valueOf(field33changprChipTyn.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfOtherChip + "\n");
                            }

                        }
                        if (LineOfPriceTxt==62) {
                            try {
                                writePrice.append(Integer.valueOf(field32changprOmivach.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfOtherOmivach + "\n");
                            }

                        }
                        if (LineOfPriceTxt==64) {
                            try {
                                writePrice.append(Integer.valueOf(field31changeprPichka.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfOtherPichka + "\n");
                            }

                        }
                        if (LineOfPriceTxt==66) {
                            try {
                                writePrice.append(Integer.valueOf(field29changprTisk.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfOtherTisk + "\n");
                            }

                        }
                        if (LineOfPriceTxt==68) {
                            try {
                                writePrice.append(Integer.valueOf(field30changprTonyvanna.getText()) +"\n");
                            }catch (NumberFormatException e) {
                                writePrice.append(PriceOfOtherTonirovka + "\n");
                            }
                        }
                    }

                    /*
                    Непарні рядки, у яких зберігається інформація про послугу не змінюються,
                    їм вертаються старі значення (переносим назву) з допоміжного документа
                    */
                    else{
                        writePrice.append(s+"\n");
                    }

                    ///Збільшення змінної-лічильника циклу
                    LineOfPriceTxt += 1;

                    ///Завершення запису
                    writePrice.flush();
                }
            }
            catch(IOException ex){
                System.out.println(ex.getMessage());
            }
        }
        catch(IOException ex){
            System.out.println(ex.getMessage());
        }

        ///Оновлення допоміжного документу для майбутніх дій на основі нового створеного
        try(BufferedReader br2 = new BufferedReader(new FileReader("Ціни/Price.txt"))) {
            String line;

            try(FileWriter writeHelper = new FileWriter("Ціни/Helper.txt", false))
            {
                while ((line = br2.readLine()) != null) {
                    try {
                        writeHelper.append(line + "\n");
                    }catch (NumberFormatException e) {
                    }
                }
            }
            catch(IOException ex){
                System.out.println(ex.getMessage());
            }
        }
        catch(IOException ex){
            System.out.println(ex.getMessage());
        }

        ///Встановлення нових цін на послуги
        setPrices();

        ///Перехід до гововної панелі
        paneHomePage.setVisible(true);
        paneOfSettingLabels.setVisible(false);

    }


}
