module com.example.kursova1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.kursova1 to javafx.fxml;
    exports com.example.kursova1;
}